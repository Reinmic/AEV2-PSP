package es.florida.entregable;

import java.util.Scanner;

/**
 * CLASSE VISTACONSOLA PER A ENVIAR EL MISSATGE
 */
public class VistaConsola {

    private Scanner scanner;

    /**
     * Vista con todos los componentes
     */
    public VistaConsola() {
        scanner = new Scanner(System.in);
    }

    /**
     * Muestra el título
     * 
     * @param titulo Título a mostrar
     */
    public void mostrarTitulo(String titulo) {
        System.out.println(titulo);
    }

    /**
     * Lee el mitssage enviat por el usuari
     * 
     * @return String Messatge ingresat per usuari
     */
    public String leerMensaje() {
        System.out.print("Ingrese el mensaje: ");
        return scanner.nextLine();
    }

    /**
     * Mostra la imatge
     * 
     * @param ruta Rute de la imatge
     */
    public void mostrarImagen(String ruta) {
        System.out.println("Imagen: " + ruta); 
    }

    /**
     * botons amb espera la entraida del usuari
     * 
     * @return int Opció seleccionat per usuari
     */
    public int mostrarBotones() {
        System.out.println("1. OK");
        System.out.println("2. CANCELAR");
        System.out.print("Seleccione una opción: ");
        return scanner.nextInt();
    }

    /**
     * Trancat la instancia del scanner
     */
    public void cerrar() {
        scanner.close();
    }
}
